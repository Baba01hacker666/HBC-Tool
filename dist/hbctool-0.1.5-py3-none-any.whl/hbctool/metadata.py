package = 'hbctool'
project = 'hbctool'
project_no_spaces = project.replace(' ', '')
version = '0.1.5'
description = ('A command-line interface for disassembling and assembling'
               'the Hermes Bytecode')
authors = ['baba01hacker']
authors_string = ', '.join(authors)
emails = ['baba01hacker@users.noreply.github.com']
license = 'MIT'
url = 'https://github.com/Baba01hacker666/HBC-Tool'